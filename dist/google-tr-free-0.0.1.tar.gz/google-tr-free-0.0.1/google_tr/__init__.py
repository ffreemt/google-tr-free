from .google_tr import google_tr

__version__ = '0.0.1'
__date__ = '2019.7.18'
VERSION = __version__